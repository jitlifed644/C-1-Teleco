//Hola mundo en C

#include <stdio.h>

int main(){
  fprintf(stdout, "Hola mundo\n");
  return 0;
}
