//Hola mundo en C

#include <stdio.h>

int main(){
  fprintf(stdout, "Adios\nHasta luego\n");
  return 0;
}
