#include <stdio.h>
#include <ctype.h>
int main (){
  char respuesta;
  printf ("Are you sure you want to close the app? (Y/N):   ");

  scanf ("%c",&respuesta);
  if (toupper(respuesta)== 'Y'){
    printf("You have chosen Yes \n");
  }
  else if(toupper(respuesta) == 'n' || respuesta == 'N'){
    printf("You have chosen No\n");
  }
  else {
    printf("You have to choose some valid answer.\n");
  }

  return 0;
}
