#include <stdio.h>

int main(){
  int indice;
  int numeros[5];

  for(indice=0; indice<5; indice++){
    numeros[indice]=indice*10;
  }
  for (indice = 0; indice<5; indice++){
    printf("%3d\n", numeros[indice]);
  }
  return 0;
}
