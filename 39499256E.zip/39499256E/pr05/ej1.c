#include <stdio.h>
void label() {
  printf ("Hola Mundo\n");
  return;
}
int main(){
  label();
  return 0;
}
